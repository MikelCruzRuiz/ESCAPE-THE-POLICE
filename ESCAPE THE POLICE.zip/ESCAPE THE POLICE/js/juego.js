	function inicializa(){
		canvas = document.getElementById("Canvas");
		ctx = canvas.getContext("2d");
		canvas.width=800;
		canvas.height=400;
		cargaImagenes();
	}
	
	var suelo=350;
	var personaje = function(x,y,vy,gravedad,salto,saltando){
		this.x=x;
		this.y=y;
		this.vy=vy;
		this.gravedad=gravedad;
		this.salto=salto;
		this.saltando = saltando;
	} 
	var obstaculo = function(x,y){
		this.x=x;
		this.y=y;
	}

		
	document.addEventListener('keydown',function(evento){
	
		if(evento.keyCode == 32){
			if(nivel.muerto==false){
				saltar();
			}
		}

	});
	function sonar(){
		if(nivel.muerto == true && centinela ==0){
			var audio_final = document.getElementById("muerto");
			audio_final.play();
			audio_final.onended=function(){
				nivel.velocidad=vel_i;
				nivel.muerto= false;
				cubo.x= ancho +100;
				policia.x=ancho+100;
				nivel.marcador= 0;
				ladron.y=suelo-50;
				centinela=0;
				boost.x=ancho+70;
				moneda.x=ancho+100;
				nivel.numNivel=1;
				contMonedas=0;

		}
			centinela++;
	}
	
	}
	
	function subirVelSonido(){
		if(nivel.muerto == false){
			var audio_vel = document.getElementById("muerto");
			audio_vel.play();
			audio_vel.ended=function(){
				nivel.velocidad=nivel.velocidad+2;
			}
		}
	}
	var ancho=800;//dimensiones del canvas
	var alto=400; //dimensiones del canvas
	var canvas,ctx;
	var centinela = 0;
	var tiempo = 0;
	var stop;
	var movP=0;
	var imgLadron, imgCubo,imgSuelo,fondo, imgBoost, imgPolicia;
	var vel_i=6;
	var nivel = {velocidad: vel_i, marcador: 0, muerto: false, numNivel:1};
	var tiempo_suelo=9;
	var agujero=new obstaculo(ancho+400,350);
	var aleatoria;
	var cont=0;
	var resto;
	var aux3=0;
	var poderDibujarAgujero=true;
	var poderDibujarMoneda=true;
	//objetos
	var ladron=new personaje(50,suelo-50,0,2,35,false);
	var policia = new obstaculo(ancho+100, suelo-75);
	var cubo = new obstaculo(ancho+100, suelo-75);
	var pinchos= new obstaculo(ancho+400,350);
	var moneda = new obstaculo(ancho+100,suelo-65);
	//var boost
	var boostCogido=false;//boost
	var boost= new obstaculo(ancho+70, suelo-50);//boost			
	var aux=false;
	var aux2=true;
	var inmune=false;
	var dibujaBoost=false;
	var contadorInmune;
	var contadorBoost=700;
	var moveBoost=false;
	// fin variables boost
	var per=1;
	var monedacogida=false;
	var contMonedas=0;
	

var mov =0;
	
	window.addEventListener('load',inicializa);
	
	

	
	
function cargaImagenes(){
	//crea el objeto de las imagenes
	imgLadron = new Image();
	imgCubo = new Image();
	fondo = new Image();
	imgSuelo= new Image();
	imgPolicia= new Image();
	imgBoost= new Image();
	imgMoneda = new Image();
	//cargar las imagenes
	imgLadron.src='img/ladron4.png'
	imgCubo.src = 'img/cubo1.png';
	fondo.src ='img/ladrillos5.jpg';
	imgSuelo.src= 'img/suelo.png';
	
	imgPolicia.src='img/policia1.png';
	imgBoost.src='img/boost4.png';
	imgMoneda.src ='img/moneda2.png';
	}
	
function comenzar(){
			clearTimeout(stop);
			stop = setTimeout(comenzar,1);
			dibujar();
	}

function dibujar(){
		
		ctx.drawImage(fondo,tiempo,0,ancho,alto);
		ctx.drawImage(fondo,tiempo-ancho,0,ancho,alto);
		//ctx.drawImage(fondo,tiempo-1178,0);
		tiempo--;
		if(tiempo<0){
				 tiempo = tiempo + ancho;
		}
			
	}

	
	function movimiento() {
		if(boostCogido==false){
			mov = (mov + 1) % 4;	
			if (mov==0){
				ctx.drawImage(imgLadron,0,0,110,110,ladron.x,ladron.y-40,100,100);// el -50 es para la correccion de tamaño ya que la imagen era muy pequeña
			}
			if (mov==1){
				ctx.drawImage(imgLadron,110,0,110,110,ladron.x,ladron.y-40,100,100);
			}
			if (mov==2){
				ctx.drawImage(imgLadron,220,0,110,110,ladron.x,ladron.y-40,100,100);
			}
			if (mov==3){
				ctx.drawImage(imgLadron,330,0,110,110,ladron.x,ladron.y-40,100,100);
			}
			if (mov==4){
				ctx.drawImage(imgLadron,0,0,110,110,ladron.x,ladron.y-40,100,100);
			}
			if (mov==5){
				ctx.drawImage(imgLadron,110,0,110,110,ladron.x,ladron.y-40,100,100);
			}
			if (mov==6){
				ctx.drawImage(imgLadron,220,0,110,110,ladron.x,ladron.y-40,100,100);
			}
			if (mov==7){
				ctx.drawImage(imgLadron,330,0,110,110,ladron.x,ladron.y-40,100,100);
			}
			mov++;
		}else{
			mov = (mov + 1) % 4;
			if (mov==0){
				ctx.drawImage(imgLadron,0,0,110,110,ladron.x,ladron.y-40,100,100);// el -50 es para la correccion de tamaño ya que la imagen era muy pequeña
			}
			if (mov==1){
				ctx.drawImage(imgLadron,110,0,110,110,ladron.x,ladron.y-40,100,100);
			}
			if (mov==2){
				ctx.drawImage(imgLadron,220,0,110,110,ladron.x,ladron.y-40,100,100);
			}
			if (mov==3){
				ctx.drawImage(imgLadron,330,0,110,110,ladron.x,ladron.y-40,100,100);
			}
		mov++;
		}//fin else			
		}//fin funcion movimiento	
		
		
	 
	
	
	
	
	function cogerBoost(){
		if(ladron.y==suelo-50){
			if(boost.x > 40 && boost.x < 60){
				boostCogido=true;
			}
		}
	}
	
	function moverBoost(){
		if(nivel.muerto==false){
			if (moveBoost==true){
				aux2=true;
				if(boost.x < -100){
					boost.x=ancho+120;
				}
				else{
					boost.x -=nivel.velocidad;
				}
		
			}
		}
	}
	function poderDibujarBoost(){
		if(boostCogido==true){
			aux2=true;
			moveBoost=false;
			contadorBoost=700;
		}
		if(boostCogido==false && aux2==true){
			if(contadorBoost>0){
				boost.x=ancho+70;
				dibujaBoost=false;
				contadorBoost=contadorBoost-1;
			}else{
				dibujaBoost=true;
				aux2=false;
			}
		}
		
	}
	
	function dibujarBoost(){
		if (boostCogido==false && dibujaBoost==true){
			ctx.drawImage(imgBoost,0,0,256,256,boost.x,boost.y,60,60);
			moveBoost=true;
		}
	}
	function inmunidad(){
		if(boostCogido==true){
			aux=true;
			contadorInmune=100;
		}
		if(boostCogido==false && aux==true){
			if(contadorInmune>0){
				inmune=true;
				contadorInmune=contadorInmune-1;
			}else{
				inmune=false;
				aux=false;
			}
		}
		
	}
	// fin funciones de boost
	// innicio dibujo obstaculos 
	function dibujaObstaculo(aleatorio){
		if(aleatorio==1){
			ctx.drawImage(imgCubo,0,0,194,260,cubo.x,cubo.y+5,75,75);	
		}
		if(aleatorio==2){
			movP=(1+movP)%2
			if(movP==0){
				ctx.drawImage(imgPolicia,351,39,39,39,policia.x,policia.y-10,120,120);	
			}
			if(movP==1){
				ctx.drawImage(imgPolicia,390,39,39,39,policia.x,policia.y-10,120,120);
			}
			movP++;
		}
	}
	
	function aumentarDificultad(){
		resto=nivel.marcador-aux3;
		if(resto>=10 && nivel.muerto==false){
			nivel.velocidad=nivel.velocidad+2;
			aux3=nivel.marcador;
			numNivel=nivel.numNivel++;
		}
	}
	 
	function movimientoObstaculo(aleatorio){
		if(aleatorio==1){
			aleatoria=1;
			if(cubo.x < -100){
				cubo.x=ancho+100;
				nivel.marcador++;
				cont=0;
			}
			else{
				cubo.x -=nivel.velocidad;
			}
		}else{
			aleatoria=2;
			if(policia.x < -100){
				policia.x=ancho+100;
				nivel.marcador++;
				cont=0;
			}
			else{
				if(nivel.velocidad > 0){
					policia.x -=nivel.velocidad+5;
				}
			}
			
		}
		return aleatorio;
	}
	
	function mover_Suelo(){
		ctx.drawImage(imgSuelo, tiempo_suelo, suelo, 1000, 50);
		ctx.drawImage(imgSuelo, tiempo_suelo+ancho, suelo, 1000, 50);
		
		if(tiempo_suelo<-ancho){
				 tiempo_suelo = tiempo_suelo +ancho;
		}else{
			tiempo_suelo-=nivel.velocidad;
			
		}
	}
	
	
	function dibuja_moneda(){
		if(monedacogida==false){
		ctx.drawImage(imgMoneda, moneda.x, moneda.y, 50,50);
		}
	}
	function movMoneda(){
			if(aleatorio==2){
			poderDibujarMoneda=true;
			if(moneda.x < -100){
				moneda.x=ancho+100;
			}
			else{
				moneda.x -=nivel.velocidad;
			}
		}else{
			if(moneda.x>cubo.x-150 && moneda.x<cubo.x+150){
				poderDibujarMoneda=false;
			}else{
				poderDibujarMoneda=true;
				if(moneda.x < -100){
					moneda.x=ancho+100;
				}
				else{
				moneda.x -=nivel.velocidad;
				}
			}
		}
	}
	function cogerMoneda(){
	if(ladron.y >=suelo-80 && monedacogida==false){
			if(moneda.x > 30 && moneda.x < 70){
				monedacogida=true;
				contMonedas++;
			}
		}
	}
	function reaparecerMoneda(){
		if(moneda.x<-100){
			monedacogida=false;
		}
		
	}
	function bonusMonedas(){
		if(contMonedas==10){
			nivel.marcador=nivel.marcador+10;
			contMonedas=0;
		}
	}
	
	function saltar(){
		if(ladron.y==suelo-50){
		ladron.saltando= true;
		ladron.vy=ladron.salto;
		}
	}
	
	function gravedad(){
		if(ladron.saltando == true){
			if(ladron.y - ladron.vy - ladron.gravedad > suelo-50){
				ladron.saltando=false;
				ladron.vy=0;
				ladron.y =suelo-50 ;
			} 
			else{
				ladron.vy -= ladron.gravedad;
				ladron.y -= ladron.vy;
			}
		}
	}
	

	
	
	function colision(){
		if(aleatorio==1){
			if(cubo.x >= 0 && cubo.x <= 90 ){
				if(ladron.y >= suelo-50 ){
					if(boostCogido==false){
						nivel.muerto =true;
						aux3=0;
						nivel.velocidad =0;
						sonar();
						contadorBoost=700;
						
						//nivel.muerto==false;
					}else{
						boostCogido=false;
					}
				}
			}//fin if cubo.x
		}
		if(aleatorio==2){
			if(policia.x >= 0 && policia.x <= 90){
				if(ladron.y >= suelo-50 ){
					if(boostCogido==false){
					nivel.muerto =true;
					nivel.velocidad =0;
					sonar();
				}else{
						boostCogido=false;
					}
			//nivel.muerto==false;
			}
		}
		
	}
	}//fin colision
	
	
	function puntuacion(){
		ctx.font = "35px  cooper black";
		ctx.fillStyle ="white";
		ctx.fillText('Puntos: '+nivel.marcador,600,50);
		if(nivel.muerto == true){
			ctx.font = "57px  Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif";
			ctx.fillText('BUSTED',250,150);
			ctx.fillText('EL JUEGO SE REANUDARÁ',100,220);
		}
	}
	function contadorMonedas(){
		ctx.font = "35px  cooper black";
		ctx.fillStyle ="white";
		ctx.fillText(contMonedas,100,50);
		ctx.drawImage(imgMoneda, 50,15,40,40);
		
	}
	function nivelP(){
		ctx.font = "35px  cooper black";
		ctx.fillStyle ="white";
		ctx.fillText('Nivel: '+nivel.numNivel,325,50);
		
	}
	




	
	//--------------------------------------------------------------------------
	//BUCLE PRINCIPAL
	
	var FPS=50;
	setInterval(function(){   //Que tiene que ejecutar
		principal();
	},1000/FPS);               //cada cuanto tiempo lo tiene que ejecutar.
	
	
	
	function principal(){ //va a ir dibujando y todo y moviendo el bicho y marcador y todo
	//borrarCanvas();//antes de dibujar borrarlo todo
	inicializa();
	dibujar();	
	sonar();
	//subirVelSonido();
	gravedad();
	if(nivel.marcador==0){
		aux3=0;
	}
	if(cont==0){
		aleatorio=Math.round(Math.random()*(2-1)+parseInt(1));
		cont=1;
	}
	a=movimientoObstaculo(aleatorio);
	if(inmune==false){
	colision(a);
	}
	poderDibujarBoost();
	

	mover_Suelo();
	dibujaObstaculo(a);
	
	dibuja_moneda();
	
	movMoneda();
	movimiento();
	puntuacion();
	contadorMonedas();
	nivelP();
	cogerBoost();
	cogerMoneda();
	reaparecerMoneda();
	aumentarDificultad();
	bonusMonedas();
	moverBoost();
	dibujarBoost();
	inmunidad();
	
	}